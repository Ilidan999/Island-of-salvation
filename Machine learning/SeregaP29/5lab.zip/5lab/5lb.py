import pandas as pd
import numpy as np
import warnings
from pandas.api.types import is_numeric_dtype

# 0. Настройка
warnings.filterwarnings('ignore')

# 1. Загрузка набора данных с указанием разделителя ";"
# Добавлен параметр sep=';', так как ваши данные разделены точкой с запятой
df = pd.read_csv('../../Downloads/homeEnergyConsumption.csv', sep=';')

# 2. Предварительный анализ [cite: 8, 36, 38]
print("--- Статистика ---")
print(df.describe())
print("\n--- Информация о столбцах ---")
df.info()

# 3. Списки признаков и 4. Вывод количества объектов [cite: 9, 10, 41]
listOfCategoricalFeatures = []
listOfNumericalFeatures = []

for column in df.columns:
    if not is_numeric_dtype(df[column]):
        print(f'\nПризнак: {column}.')
        print('Значения и их количество в наборе:')
        listOfCategoricalFeatures.append(column)
        print(df[column].value_counts())
    else:
        listOfNumericalFeatures.append(column)

# Удаление технического признака по условию лаб. работы [cite: 50]
if 'AirConditioning' in listOfNumericalFeatures:
    listOfNumericalFeatures.remove('AirConditioning')

# 5. Удаление строк по процентилям 2.5 и 97.5 [cite: 12, 65]
for column in listOfNumericalFeatures:
    minLimit = df[column].quantile(0.025)
    maxLimit = df[column].quantile(0.975)
    df = df.loc[(df[column] >= minLimit) & (df[column] <= maxLimit)]

# 6. Замена WaterHeaterSize на моду и кодирование [cite: 13, 68, 71]
# Теперь столбец будет найден корректно
modeWaterHeaterSize = df['WaterHeaterSize'].mode()[0]
df['WaterHeaterSize'].replace('None', modeWaterHeaterSize, inplace=True)
waterHeaterSizeDict = {'Small': 1, 'Medium': 2, 'Large': 3}
df['WaterHeaterSize'] = df['WaterHeaterSize'].map(waterHeaterSizeDict)

# 7. Устранение отрицательных значений в NumOfRoomsCooled [cite: 14, 73]
df.loc[df['NumOfRoomsCooled'] < 0, 'NumOfRoomsCooled'] = 0

# 8. Удаление строк без HeatingEquipmentType [cite: 15, 75]
df = df.dropna(subset=['HeatingEquipmentType'])

# 9. RoofType и StovenFuelType -> Unknown [cite: 16, 77, 80]
df['RoofType'] = df['RoofType'].replace(np.nan, 'Unknown')
df['StovenFuelType'] = df['StovenFuelType'].replace('-', 'Unknown')

# 10. Закодировать HeatingEquipmentAge [cite: 17, 84]
ageDict = {
    '<2 Years old': 1, '2-4 Years old': 2, '5-9 Years old': 3,
    '10-14 Years old': 4, '15-19 Years old': 5, '>20 Years old': 6
}
df['HeatingEquipmentAge'] = df['HeatingEquipmentAge'].map(ageDict)

# 11. Удалить редкие категории (меньше 3%) [cite: 17, 93, 99]
threshold = df.shape[0] * 0.03
for column in listOfCategoricalFeatures:
    # Проверяем, остался ли столбец в df (после map типы могли измениться)
    if column in df.columns and not is_numeric_dtype(df[column]):
        counts = df[column].value_counts()
        listOfIndices = counts.index[counts > threshold].tolist()
        df = df.loc[df[column].isin(listOfIndices)]

# 12. Сохранение результата [cite: 18, 100]
df.to_csv('homeEnergyConsumption_cleaned.csv', index=False)
print("\n[УСПЕХ]: Обработка завершена. Данные сохранены в 'homeEnergyConsumption_cleaned.csv'")