import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# --- 1. НАСТРОЙКА ПУТЕЙ И ЗАГРУЗКА ---
base_path = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_path, 'data')

def load_csv(file_name):
    for path in [os.path.join(data_dir, file_name), os.path.join(base_path, file_name)]:
        if os.path.exists(path):
            df = pd.read_csv(path, sep=';')
            df.columns = df.columns.str.strip()
            return df
    return None

user_info = load_csv('user_info.csv')
chat = load_csv('chat.csv')
connection = load_csv('connection.csv')
user_events = load_csv('user_events.csv')
meeting = load_csv('meeting.csv')

if any(x is None for x in [user_info, chat, connection, user_events, meeting]):
    print("Ошибка: Не все файлы найдены.")
    exit()

# --- 2. ГЕНЕРАЦИЯ НОВЫХ ПРИЗНАКОВ ---

# ПРИЗНАК 1: Социальная активность (сообщения в чате)
chat_counts = chat.groupby('sender_id').size().rename('total_chat_messages')

# ПРИЗНАК 2: Мобильность (доля использования мобильных устройств)
connection['is_mobile'] = connection['device'].isin(['android', 'ios']).astype(int)
mobile_share = connection.groupby('user_id')['is_mobile'].mean().rename('mobile_usage_share')

# ПРИЗНАК 3: Пунктуальность (задержка первого действия на уроке)
# Исправляем ошибку с форматом времени через format='ISO8601'
user_events['created_at'] = pd.to_datetime(user_events['created_at'], format='ISO8601')
meeting['created_at'] = pd.to_datetime(meeting['created_at'], format='ISO8601')

events_with_start = user_events.merge(meeting[['lesson_id', 'created_at']], on='lesson_id', suffixes=('_event', '_meet'))

# Считаем разницу в минутах
events_with_start['delay'] = (events_with_start['created_at_event'] - events_with_start['created_at_meet']).dt.total_seconds() / 60
# Берем только первое событие для каждого пользователя на каждом уроке
first_event_delays = events_with_start.groupby(['user_id', 'lesson_id'])['delay'].min().reset_index()
avg_delay = first_event_delays.groupby('user_id')['delay'].mean().rename('avg_arrival_delay')

# --- 3. СБОРКА ИТОГОВОГО ДАТАСЕТА ---
df = user_info[['user_id', 'churn']].copy()
df['churn'] = df['churn'].astype(int)

df = df.merge(chat_counts, left_on='user_id', right_index=True, how='left').fillna(0)
df = df.merge(mobile_share, on='user_id', how='left').fillna(0)
df = df.merge(avg_delay, on='user_id', how='left').fillna(0)

# --- 4. ПОСТРОЕНИЕ ЛИНЕЙНЫХ ГРАФИКОВ ---
plt.figure(figsize=(18, 5))

# График 1: Социальная активность
# Используем qcut для разбиения на равные группы по кол-ву сообщений
df['chat_rank'] = pd.qcut(df['total_chat_messages'].rank(method='first'), 5, labels=False)
line1 = df.groupby('chat_rank')['churn'].mean()
plt.subplot(1, 3, 1)
plt.plot(line1.index, line1.values, marker='o', color='mediumorchid', linewidth=2)
plt.title('Влияние социальной активности на отток')
plt.xlabel('Группы по количеству сообщений (от 0 до макс)')
plt.ylabel('Средний уровень оттока')
plt.grid(True, alpha=0.3)

# График 2: Мобильные устройства
line2 = df.groupby(df['mobile_usage_share'].round(1))['churn'].mean()
plt.subplot(1, 3, 2)
plt.plot(line2.index, line2.values, marker='s', color='darkorange', linewidth=2)
plt.title('Зависимость оттока от типа устройства')
plt.xlabel('Доля мобильных сессий (0.0 - Web, 1.0 - Mobile)')
plt.ylabel('Средний уровень оттока')
plt.grid(True, alpha=0.3)

# График 3: Пунктуальность
df['delay_bin'] = (df['avg_arrival_delay'] // 5) * 5
line3 = df[df['delay_bin'] <= 30].groupby('delay_bin')['churn'].mean() # Ограничим 30 минутами для наглядности
plt.subplot(1, 3, 3)
plt.plot(line3.index, line3.values, marker='^', color='crimson', linewidth=2)
plt.title('Тренд оттока в зависимости от опозданий')
plt.xlabel('Среднее опоздание на урок (мин)')
plt.ylabel('Средний уровень оттока')
plt.grid(True, alpha=0.3)



plt.tight_layout()
plt.show()
