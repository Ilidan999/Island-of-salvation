import streamlit as st
from PIL import Image
import torch
from class_list import idx2label
from models import classify_image


# Заголовок приложения
st.title("Классификация изображений")

# Инструкция для пользователя
st.write("Загрузите изображение, чтобы получить предсказание модели")

# Загрузка изображения
uploaded_file = st.file_uploader(
    "Выберите изображение...",
    type=["jpg", "jpeg", "png"],
    accept_multiple_files=True
)

if uploaded_file:
    img = []
    for file in uploaded_file:
        # Отображение загруженного изображения
        image = Image.open(file)
        img.append(image)

    st.image(img, use_column_width=True)

    # Кнопка для запуска классификации
    if st.button("Классифицировать"):
        # Предсказание
        predictions = classify_image(img)
        # Отображение результатов
        st.write("Распределение по классам:")
        for file, prob in zip(uploaded_file, predictions):
            st.write(f"**Файл: {file.name}**")
            chart_data = {}

            for i, p in enumerate(prob):
                if p > 0.01:
                    class_name = idx2label[i]
                    st.write(f"Класс {class_name}: {p:.2f}")
                    chart_data[class_name] = float(p)

            if chart_data:
                st.bar_chart(chart_data)
