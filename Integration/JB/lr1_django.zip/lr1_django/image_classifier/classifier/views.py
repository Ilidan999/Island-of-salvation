from django.shortcuts import render
from .forms import ImageUploadForm
from .models import ImageUpload
from .ml_model import classify_image
from .file_ml.class_list import idx2label


def upload_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if request.FILES.getlist('image'):
            predict_list = {}

            for file in request.FILES.getlist('image'):
                instance = ImageUpload(image=file)
                instance.save()

                image_path = instance.image.path  # Путь к загруженному изображению
                predictions = classify_image(image_path)  # Получаем предсказания

                # Вытаскиваем классы и вероятности для отображения
                class_probabilities = [(idx2label[i], float(p)) for i, p in enumerate(predictions)]
                predict_list[instance.image.url] = class_probabilities
            return render(request, 'classifier/result.html', {
                'predict_list': predict_list,
            })
    else:
        form = ImageUploadForm()

    return render(request, 'classifier/upload.html', {'form': form})