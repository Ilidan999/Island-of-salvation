from django import forms
from .models import ImageUpload


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class ImageUploadForm(forms.ModelForm):
    class Meta:
        model = ImageUpload
        fields = ['image']
        widgets = {'image': MultipleFileInput()}
