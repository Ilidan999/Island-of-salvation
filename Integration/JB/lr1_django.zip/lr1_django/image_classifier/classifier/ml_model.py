import os
import torch
from torchvision import transforms
from PIL import Image
from image_classifier import settings


# Загрузка предобученной модели
model_path = os.path.join(settings.BASE_DIR, 'classifier', 'file_ml/resnet18.pth')
model = torch.load(model_path, map_location=torch.device('cpu'), weights_only=False)
model.eval()

# Преобразование изображения для модели
transform = transforms.Compose([
    transforms.Resize(256),  # уменьшение фото пропорционально, чтобы меньшая сторона стала 256
    transforms.CenterCrop(224),  # вырезание квадрата 224x224 из центра
    transforms.ToTensor(),  # делит всё на 255, превращая диапазон в [0.0, 1.0]
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),  # среднее значение (mean)
    # и стандартное отклонени из датасета ImageNet
])  # в результате мы получаем числа примерно от -2 до +2


def classify_image(image_path):
    # Открытие изображения и его предобработка
    image = Image.open(image_path)
    image = transform(image).unsqueeze(0)  # Добавление batch dimension (фейк измерение)

    # Прогон через модель
    with torch.no_grad():  # режим «Только просмотр»
        output = model(image)

    # Преобразование результатов
    probabilities = torch.nn.functional.softmax(output[0], dim=0)
    return probabilities
