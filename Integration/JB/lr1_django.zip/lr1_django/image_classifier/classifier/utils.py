import torch
from torchvision import models

print("Загрузка модели из интернета...")
model = models.resnet18(weights='DEFAULT')

model.eval()

save_filename = 'resnet18.pth'
torch.save(model, save_filename)
