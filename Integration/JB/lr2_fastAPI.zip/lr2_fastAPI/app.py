from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request
from classifier.class_list import idx2label
from models import classify_image
from typing import List
import logging
import time


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# Инициализация приложения
app = FastAPI()

# Подключение шаблонов
templates = Jinja2Templates(directory="templates")

# Хранилище загруженных файлов
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


# Обработка загрузки изображений и предсказаний
@app.post("/upload/")
async def upload_image(file_list: List[UploadFile] = File(...)):
    logger.info(f"Запрос POST /upload/ получен. Количество файлов: {len(file_list)}")

    all_results = []

    for file in file_list:
        logger.info(f"Начинаем обработку файла: {file.filename}")

        file_location = f"uploads/{file.filename}"
        with open(file_location, "wb") as buffer:
            buffer.write(file.file.read())

        start_time = time.time()

        predictions = classify_image(file_location)

        finish_time = time.time()
        res_time = (finish_time - start_time) * 1000

        pairs = list(enumerate(predictions))
        top_3 = sorted(pairs, key=lambda x: x[1], reverse=True)[:3]

        class_probabilities = [(idx2label[idx], float(prob)) for idx, prob in top_3]
        all_results.append((file_location, class_probabilities, res_time))

        logger.info(f"Файл {file.filename} успешно классифицирован за {res_time:.2f} мс")

    return templates.TemplateResponse("result.html", {"request": {}, "all_results": all_results})


# Страница для загрузки изображений
@app.get("/", response_class=HTMLResponse)
async def upload_form(request: Request):
    return templates.TemplateResponse("upload.html", {"request": request})

